#!/usr/bin/env python3
# main.py
"""
主程序入口
"""

import argparse
import yaml
from pathlib import Path

from src.simulation import MECSimulator
from src.visualization import Visualization
from src.utils import print_banner, save_results


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description='移动边缘计算反向拍卖机制仿真')

    parser.add_argument('--config', type=str, default='config.yaml',
                        help='配置文件路径')
    parser.add_argument('--mode', type=str, default='full',
                        choices=['single', 'batch', 'full', 'plot'],
                        help='运行模式: single(单次实验), batch(批量实验), '
                             'full(完整实验+绘图), plot(仅绘图)')
    parser.add_argument('--tasks', type=int, default=100,
                        help='单次实验的任务数量')
    parser.add_argument('--servers', type=int, default=8,
                        help='单次实验的服务器数量')
    parser.add_argument('--output', type=str, default='experiments/results.pkl',
                        help='结果保存路径')
    parser.add_argument('--load', type=str, default=None,
                        help='加载已有结果进行绘图')

    return parser.parse_args()


def main():
    """主函数"""
    args = parse_args()

    print_banner("移动边缘计算反向拍卖机制仿真系统")

    # 加载配置
    if not Path(args.config).exists():
        print(f"配置文件不存在: {args.config}")
        print("使用默认配置...")
        args.config = None

    if args.mode == 'plot' and args.load:
        # 仅绘图模式
        print("加载已有结果并绘图...")

        from src.utils import load_results
        results = load_results(args.load)

        # 加载配置
        with open('config.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)

        visualizer = Visualization(config)
        visualizer.plot_performance_comparison(results)
        visualizer.plot_detailed_analysis(results)
        visualizer.generate_report(results)

        print("绘图完成！")
        return

    # 初始化仿真器
    config_file = args.config if args.config else None
    simulator = MECSimulator(config_file)

    if args.mode in ['single', 'full']:
        # 运行单次实验
        print(f"运行单次实验: {args.tasks}任务, {args.servers}服务器")
        results = simulator.run_single_experiment(args.tasks, args.servers)

        # 打印结果
        print("\n单次实验结果:")
        print("-" * 60)
        for algo, metrics in results.items():
            if metrics:
                print(f"\n{algo}:")
                for key, value in metrics.items():
                    if isinstance(value, float):
                        print(f"  {key}: {value:.2f}")
                    else:
                        print(f"  {key}: {value}")

        # 保存结果
        save_results(results, 'experiments/single_result.pkl')

    if args.mode in ['batch', 'full']:
        # 运行批量实验
        print("\n运行批量实验...")
        batch_results = simulator.run_batch_experiments()

        # 保存结果
        save_results(batch_results, args.output)

        if args.mode == 'full':
            # 绘图和生成报告
            print("\n生成图表和报告...")

            # 加载配置
            with open('config.yaml' if args.config is None else args.config,
                      'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)

            visualizer = Visualization(config)

            # 绘制图表
            visualizer.plot_system_framework()
            visualizer.plot_performance_comparison(batch_results)
            visualizer.plot_detailed_analysis(batch_results)

            # 生成报告
            report = visualizer.generate_report(batch_results)
            print("\n" + report)

    print_banner("仿真完成！")


if __name__ == "__main__":
    main()