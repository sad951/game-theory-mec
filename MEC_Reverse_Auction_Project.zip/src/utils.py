# src/utils.py
"""
工具函数
"""

import time
from functools import wraps
from typing import Callable, Any
import numpy as np


class Timer:
    """计时器装饰器"""

    def __init__(self, name: str = None):
        self.name = name

    def __call__(self, func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()

            wrapper.execution_time = end_time - start_time

            if self.name:
                print(f"{self.name} 执行时间: {wrapper.execution_time:.4f}秒")
            else:
                print(f"{func.__name__} 执行时间: {wrapper.execution_time:.4f}秒")

            return result

        wrapper.execution_time = 0
        return wrapper


def print_banner(text: str, width: int = 60) -> None:
    """打印横幅"""
    border = "=" * width
    print(border)
    print(text.center(width))
    print(border)


def save_results(results: dict, filename: str) -> None:
    """保存实验结果"""
    import json
    import pickle

    # 保存为JSON
    json_filename = filename.replace('.pkl', '.json')
    with open(json_filename, 'w', encoding='utf-8') as f:
        # 转换NumPy类型为Python标准类型
        def convert(obj):
            if isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, dict):
                return {k: convert(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [convert(item) for item in obj]
            else:
                return obj

        json.dump(convert(results), f, indent=2, ensure_ascii=False)

    # 保存为Pickle（保留Python对象）
    pickle_filename = filename if filename.endswith('.pkl') else filename + '.pkl'
    with open(pickle_filename, 'wb') as f:
        pickle.dump(results, f)

    print(f"结果已保存到: {json_filename} 和 {pickle_filename}")


def load_results(filename: str) -> dict:
    """加载实验结果"""
    import pickle

    if filename.endswith('.pkl'):
        with open(filename, 'rb') as f:
            return pickle.load(f)
    else:
        raise ValueError("只支持.pkl格式的文件")


def calculate_statistics(values: list) -> dict:
    """计算统计指标"""
    if not values:
        return {}

    values_array = np.array(values)

    return {
        'mean': np.mean(values_array),
        'median': np.median(values_array),
        'std': np.std(values_array),
        'min': np.min(values_array),
        'max': np.max(values_array),
        'count': len(values_array)
    }