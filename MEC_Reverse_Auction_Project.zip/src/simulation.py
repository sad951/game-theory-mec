# src/simulation.py
"""
仿真实验框架
"""

import numpy as np
from typing import List, Dict, Tuple, Any, Optional
import yaml
import logging
from pathlib import Path
from tqdm import tqdm

from .models import Task, Server
from .auction_mechanisms import GreedyReverseAuction, VCGReverseAuction, RandomAllocation
from .evaluation import Evaluator


class MECSimulator:
    """移动边缘计算仿真器"""

    def __init__(self, config_path: str = "config.yaml"):
        """
        初始化仿真器

        Args:
            config_path: 配置文件路径
        """
        # 加载配置
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = yaml.safe_load(f)

        # 设置随机种子
        np.random.seed(self.config['simulation']['random_seed'])

        # 设置日志
        self._setup_logging()

        # 算法注册
        self.algorithms = {
            'reverse_auction': GreedyReverseAuction,
            'vcg_auction': VCGReverseAuction,
            'random_allocation': RandomAllocation
        }

        self.logger = logging.getLogger(__name__)
        self.logger.info("MEC仿真器初始化完成")

    def _setup_logging(self):
        """设置日志"""
        log_dir = Path("experiments/logs")
        log_dir.mkdir(parents=True, exist_ok=True)

        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / "simulation.log"),
                logging.StreamHandler()
            ]
        )

    def generate_tasks(self, num_tasks: int) -> List[Task]:
        """生成任务集合"""
        tasks = []
        task_config = self.config['tasks']

        for i in range(num_tasks):
            task = Task(
                task_id=i,
                computing_demand=np.random.uniform(*task_config['computing_demand_range']),
                data_size=np.random.uniform(*task_config['data_size_range']),
                deadline=np.random.uniform(*task_config['deadline_range']),
                max_budget=np.random.uniform(*task_config['budget_range'])
            )
            tasks.append(task)

        self.logger.info(f"生成了 {num_tasks} 个任务")
        return tasks

    def generate_servers(self, num_servers: int) -> List[Server]:
        """生成服务器集合"""
        servers = []
        server_config = self.config['servers']

        for i in range(num_servers):
            server = Server(
                server_id=i,
                cpu_capacity=np.random.uniform(*server_config['cpu_capacity_range']),
                unit_price=np.random.uniform(*server_config['unit_price_range']),
                energy_cost=np.random.uniform(*server_config['energy_cost_range']),
                reliability=np.random.uniform(*server_config['reliability_range'])
            )
            servers.append(server)

        self.logger.info(f"生成了 {num_servers} 个服务器")
        return servers

    def run_single_experiment(self, num_tasks: int, num_servers: int) -> Dict[str, Any]:
        """
        运行单次实验

        Returns:
            各算法的性能指标
        """
        # 生成场景
        tasks = self.generate_tasks(num_tasks)
        servers = self.generate_servers(num_servers)

        results = {}

        # 运行所有算法
        for algo_name, AlgoClass in self.algorithms.items():
            try:
                self.logger.info(f"运行算法: {algo_name}")

                # 初始化算法
                if algo_name == 'random_allocation':
                    algorithm = AlgoClass(tasks, servers)
                else:
                    algorithm = AlgoClass(tasks, servers, self.config['auction']['weights'])

                # 运行算法
                if algo_name == 'random_allocation':
                    allocations = algorithm.run_allocation()
                else:
                    allocations = algorithm.run_auction(strategy="truthful")

                # 评估结果
                evaluator = Evaluator(tasks, servers, allocations)
                metrics = evaluator.evaluate_all()

                # 添加计算时间（如果算法有计时器）
                if hasattr(algorithm, 'run_auction'):
                    metrics['computation_time'] = algorithm.run_auction.execution_time
                elif hasattr(algorithm, 'run_allocation'):
                    metrics['computation_time'] = algorithm.run_allocation.execution_time

                results[algo_name] = metrics

                self.logger.info(f"{algo_name} 完成: {len(allocations)}/{num_tasks} 个任务分配")

            except Exception as e:
                self.logger.error(f"算法 {algo_name} 运行失败: {str(e)}")
                results[algo_name] = None

        return results

    def run_batch_experiments(self) -> Dict[str, List[Dict]]:
        """
        运行批量实验

        Returns:
            所有实验结果的字典
        """
        exp_config = self.config['experiment']
        task_counts = exp_config['task_range']
        server_counts = exp_config['server_range']

        all_results = {algo: [] for algo in self.algorithms.keys()}

        self.logger.info(f"开始批量实验: {len(task_counts)} × {len(server_counts)} 种配置")

        # 使用进度条
        total_experiments = len(task_counts) * len(server_counts)
        progress_bar = tqdm(total=total_experiments, desc="运行实验")

        # 遍历所有配置
        for task_count in task_counts:
            for server_count in server_counts:
                self.logger.info(f"实验配置: {task_count}任务, {server_count}服务器")

                # 运行多次实验取平均
                batch_results = {algo: [] for algo in self.algorithms.keys()}

                for exp_idx in range(self.config['experiment']['num_experiments']):
                    # 每次实验使用不同的随机种子
                    np.random.seed(exp_idx)

                    single_result = self.run_single_experiment(task_count, server_count)

                    # 收集结果
                    for algo, metrics in single_result.items():
                        if metrics:
                            batch_results[algo].append(metrics)

                # 计算平均结果
                for algo, metrics_list in batch_results.items():
                    if metrics_list:
                        avg_metrics = self._average_metrics(metrics_list)
                        avg_metrics['task_count'] = task_count
                        avg_metrics['server_count'] = server_count
                        all_results[algo].append(avg_metrics)

                progress_bar.update(1)

        progress_bar.close()
        self.logger.info("批量实验完成")

        return all_results

    def _average_metrics(self, metrics_list: List[Dict]) -> Dict:
        """计算指标平均值"""
        if not metrics_list:
            return {}

        avg_metrics = {}
        for key in metrics_list[0].keys():
            if isinstance(metrics_list[0][key], (int, float)):
                values = [m[key] for m in metrics_list if key in m]
                avg_metrics[key] = np.mean(values) if values else 0
            else:
                # 非数值类型，取第一个
                avg_metrics[key] = metrics_list[0][key]

        return avg_metrics