# src/auction_mechanisms.py
"""
反向拍卖机制实现
"""

import numpy as np
from typing import List, Dict, Tuple, Optional
from .models import Task, Server, Bid, Allocation
from .utils import Timer


class ReverseAuction:
    """反向拍卖基类"""

    def __init__(self, tasks: List[Task], servers: List[Server],
                 weights: Dict[str, float] = None):
        """
        初始化拍卖机制

        Args:
            tasks: 任务列表
            servers: 服务器列表
            weights: 评分权重 {'price': 0.6, 'time': 0.3, 'quality': 0.1}
        """
        self.tasks = tasks
        self.servers = servers
        self.bids = []

        # 默认权重
        self.weights = weights or {'price': 0.6, 'time': 0.3, 'quality': 0.1}

        # 验证权重和为1
        total_weight = sum(self.weights.values())
        if abs(total_weight - 1.0) > 1e-6:
            raise ValueError(f"权重和必须为1，当前和为{total_weight}")

    def collect_bids(self, strategy: str = "truthful") -> List[Bid]:
        """
        收集服务器投标

        Args:
            strategy: 投标策略
                - "truthful": 真实成本报价
                - "random": 随机报价
                - "aggressive": 激进报价（低于成本）
                - "conservative": 保守报价（高于成本）
        """
        self.bids = []

        for server in self.servers:
            for task in self.tasks:
                # 计算服务时间
                service_time = task.computing_demand / server.cpu_capacity

                # 检查是否满足截止时间
                if service_time > task.deadline:
                    continue

                # 计算实际成本
                energy_cost = server.energy_cost * task.computing_demand
                actual_cost = server.unit_price * task.computing_demand + energy_cost

                # 根据策略调整报价
                if strategy == "truthful":
                    bid_price = actual_cost
                elif strategy == "random":
                    # 在成本基础上±20%随机波动
                    bid_price = actual_cost * np.random.uniform(0.8, 1.2)
                elif strategy == "aggressive":
                    # 低于成本竞标（抢占市场）
                    bid_price = actual_cost * np.random.uniform(0.7, 0.95)
                elif strategy == "conservative":
                    # 高于成本竞标（确保利润）
                    bid_price = actual_cost * np.random.uniform(1.05, 1.3)
                else:
                    raise ValueError(f"未知策略: {strategy}")

                # 检查报价是否超过用户预算
                if bid_price > task.max_budget:
                    continue

                # 计算服务质量评分
                quality_score = self._calculate_quality_score(server, task, service_time)

                # 创建投标
                bid = Bid(
                    server_id=server.server_id,
                    task_id=task.task_id,
                    bid_price=bid_price,
                    estimated_time=service_time,
                    quality_score=quality_score
                )
                self.bids.append(bid)

        return self.bids

    def _calculate_quality_score(self, server: Server, task: Task, service_time: float) -> float:
        """计算服务质量评分"""
        # 基于可靠性和响应时间
        time_score = 1.0 / (1.0 + service_time / task.deadline)
        reliability_score = server.reliability

        # 综合评分
        quality_score = 0.7 * reliability_score + 0.3 * time_score
        return min(max(quality_score, 0), 1)  # 限制在0-1之间

    def _calculate_bid_score(self, bid: Bid) -> float:
        """计算投标综合得分"""
        # 价格越低越好，时间越短越好，质量越高越好
        price_score = 1.0 / (bid.bid_price + 1e-6)
        time_score = 1.0 / (bid.estimated_time + 1e-6)
        quality_score = bid.quality_score

        # 加权求和
        total_score = (self.weights['price'] * price_score +
                       self.weights['time'] * time_score +
                       self.weights['quality'] * quality_score)

        return total_score


class GreedyReverseAuction(ReverseAuction):
    """贪心反向拍卖算法"""

    @Timer()
    def run_auction(self, strategy: str = "truthful") -> Dict[int, Allocation]:
        """
        运行贪心拍卖算法

        Returns:
            分配结果字典 {task_id: Allocation}
        """
        # 收集投标
        self.collect_bids(strategy)

        # 按任务分组投标
        task_bids = {}
        for bid in self.bids:
            if bid.task_id not in task_bids:
                task_bids[bid.task_id] = []
            task_bids[bid.task_id].append(bid)

        # 分配结果
        allocations = {}

        # 为每个任务选择最优投标
        for task_id, bids in task_bids.items():
            if not bids:
                continue

            # 计算每个投标的得分
            scored_bids = []
            for bid in bids:
                score = self._calculate_bid_score(bid)
                scored_bids.append((score, bid))

            # 选择得分最高的投标
            scored_bids.sort(key=lambda x: x[0], reverse=True)
            _, best_bid = scored_bids[0]

            # 确定支付价格（第二价格拍卖）
            if len(scored_bids) > 1:
                # 找到第二高的得分
                second_best_score = scored_bids[1][0]

                # 将第二高的得分转换为价格
                # 这是简化实现，实际需要解方程
                payment = self._score_to_price(second_best_score, best_bid)
            else:
                # 只有一个投标者
                payment = best_bid.bid_price

            # 获取对应的任务和服务器
            task = next(t for t in self.tasks if t.task_id == task_id)
            server = next(s for s in self.servers if s.server_id == best_bid.server_id)

            # 计算实际成本
            actual_cost = (server.unit_price * task.computing_demand +
                           server.energy_cost * task.computing_demand)

            # 创建分配结果
            allocation = Allocation(
                task_id=task_id,
                server_id=best_bid.server_id,
                payment=payment,
                completion_time=best_bid.estimated_time,
                actual_cost=actual_cost
            )
            allocations[task_id] = allocation

        return allocations

    def _score_to_price(self, target_score: float, reference_bid: Bid) -> float:
        """
        将得分转换为价格（简化实现）
        在实际应用中，这需要更复杂的计算
        """
        # 基于参考投标的价格进行线性估计
        reference_score = self._calculate_bid_score(reference_bid)

        # 得分与价格成反比
        if target_score <= 0:
            return float('inf')

        # 简化估计：价格 = 参考价格 * (参考得分 / 目标得分)
        estimated_price = reference_bid.bid_price * (reference_score / target_score)

        return max(estimated_price, 0)  # 确保非负


class VCGReverseAuction(ReverseAuction):
    """VCG反向拍卖算法"""

    @Timer()
    def run_auction(self, strategy: str = "truthful") -> Dict[int, Allocation]:
        """
        运行VCG拍卖算法

        Returns:
            分配结果字典 {task_id: Allocation}
        """
        # 收集投标
        self.collect_bids(strategy)

        # 使用贪心算法计算初始分配
        greedy_auction = GreedyReverseAuction(self.tasks, self.servers, self.weights)
        allocations = greedy_auction.run_auction(strategy)

        # 计算VCG支付价格
        vcg_allocations = {}

        for task_id, allocation in allocations.items():
            # 排除当前任务后重新计算最优分配
            remaining_tasks = [t for t in self.tasks if t.task_id != task_id]
            remaining_auction = GreedyReverseAuction(remaining_tasks, self.servers, self.weights)
            remaining_allocations = remaining_auction.run_auction(strategy)

            # 计算社会福利
            social_welfare_with = self._calculate_social_welfare(allocations)
            social_welfare_without = self._calculate_social_welfare(remaining_allocations)

            # 其他参与者在该任务存在时的总效用
            other_utility_with = 0
            for tid, alloc in allocations.items():
                if tid != task_id:
                    task = next(t for t in self.tasks if t.task_id == tid)
                    other_utility_with += alloc.utility(task)

            # 其他参与者在该任务不存在时的总效用
            other_utility_without = 0
            for tid, alloc in remaining_allocations.items():
                task = next(t for t in remaining_tasks if t.task_id == tid)
                other_utility_without += alloc.utility(task)

            # VCG支付：对其他参与者的影响
            externality = other_utility_without - other_utility_with

            # 更新支付价格
            vcg_allocation = Allocation(
                task_id=allocation.task_id,
                server_id=allocation.server_id,
                payment=max(externality, 0),  # 确保非负
                completion_time=allocation.completion_time,
                actual_cost=allocation.actual_cost
            )
            vcg_allocations[task_id] = vcg_allocation

        return vcg_allocations

    def _calculate_social_welfare(self, allocations: Dict[int, Allocation]) -> float:
        """计算社会福利"""
        welfare = 0

        for task_id, allocation in allocations.items():
            task = next(t for t in self.tasks if t.task_id == task_id)
            welfare += allocation.utility(task)  # 用户效用
            welfare += allocation.profit()  # 服务器利润

        return welfare


class RandomAllocation:
    """随机分配基准算法"""

    def __init__(self, tasks: List[Task], servers: List[Server]):
        self.tasks = tasks
        self.servers = servers

    @Timer()
    def run_allocation(self) -> Dict[int, Allocation]:
        """随机分配任务"""
        allocations = {}

        for task in self.tasks:
            # 随机选择一个服务器
            server = np.random.choice(self.servers)

            # 计算服务时间和成本
            service_time = task.computing_demand / server.cpu_capacity

            # 检查是否满足截止时间
            if service_time > task.deadline:
                continue

            # 随机生成价格（在成本和预算之间）
            cost = server.unit_price * task.computing_demand + server.energy_cost * task.computing_demand
            max_price = min(task.max_budget, cost * 1.5)  # 不超过预算的150%
            min_price = cost * 0.8  # 不低于成本的80%

            if max_price < min_price:
                continue

            payment = np.random.uniform(min_price, max_price)

            # 创建分配结果
            allocation = Allocation(
                task_id=task.task_id,
                server_id=server.server_id,
                payment=payment,
                completion_time=service_time,
                actual_cost=cost
            )
            allocations[task.task_id] = allocation

        return allocations