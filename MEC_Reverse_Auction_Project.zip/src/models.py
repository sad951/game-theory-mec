# src/models.py
"""
数据模型定义
"""

from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import numpy as np


@dataclass
class Task:
    """计算任务模型"""
    task_id: int
    computing_demand: float  # 计算需求 (GHz)
    data_size: float  # 数据大小 (MB)
    deadline: float  # 截止时间 (秒)
    max_budget: float  # 最大预算 (元)

    def __post_init__(self):
        """验证任务参数"""
        assert self.computing_demand > 0, "计算需求必须大于0"
        assert self.data_size > 0, "数据大小必须大于0"
        assert self.deadline > 0, "截止时间必须大于0"
        assert self.max_budget > 0, "预算必须大于0"


@dataclass
class Server:
    """边缘服务器模型"""
    server_id: int
    cpu_capacity: float  # CPU容量 (GHz)
    unit_price: float  # 单位价格 (元/GHz)
    energy_cost: float  # 能耗成本 (元/任务)
    reliability: float  # 可靠性 (0-1)

    def __post_init__(self):
        """验证服务器参数"""
        assert self.cpu_capacity > 0, "CPU容量必须大于0"
        assert self.unit_price > 0, "单位价格必须大于0"
        assert self.energy_cost >= 0, "能耗成本不能为负"
        assert 0 <= self.reliability <= 1, "可靠性必须在0-1之间"


@dataclass
class Bid:
    """投标信息"""
    server_id: int
    task_id: int
    bid_price: float  # 投标价格
    estimated_time: float  # 估计完成时间
    quality_score: float  # 服务质量评分

    def __post_init__(self):
        """验证投标参数"""
        assert self.bid_price > 0, "投标价格必须大于0"
        assert self.estimated_time > 0, "估计时间必须大于0"
        assert 0 <= self.quality_score <= 1, "服务质量评分必须在0-1之间"


@dataclass
class Allocation:
    """分配结果"""
    task_id: int
    server_id: int
    payment: float  # 支付价格
    completion_time: float  # 预计完成时间
    actual_cost: float  # 服务器实际成本

    def utility(self, task: Task) -> float:
        """计算用户效用"""
        return task.max_budget - self.payment

    def profit(self) -> float:
        """计算服务器利润"""
        return self.payment - self.actual_cost