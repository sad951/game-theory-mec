# src/evaluation.py
"""
性能评估指标
"""

import numpy as np
from typing import List, Dict, Any
from scipy.stats import entropy
from .models import Task, Server, Allocation


class Evaluator:
    """性能评估器"""

    def __init__(self, tasks: List[Task], servers: List[Server],
                 allocations: Dict[int, Allocation]):
        """
        初始化评估器

        Args:
            tasks: 任务列表
            servers: 服务器列表
            allocations: 分配结果
        """
        self.tasks = tasks
        self.servers = servers
        self.allocations = allocations

    def evaluate_all(self) -> Dict[str, Any]:
        """计算所有性能指标"""
        metrics = {}

        # 基本指标
        metrics['tasks_allocated'] = len(self.allocations)
        metrics['allocation_rate'] = len(self.allocations) / len(self.tasks)

        # 成本相关指标
        cost_metrics = self._evaluate_costs()
        metrics.update(cost_metrics)

        # 延迟相关指标
        delay_metrics = self._evaluate_delays()
        metrics.update(delay_metrics)

        # 效用相关指标
        utility_metrics = self._evaluate_utilities()
        metrics.update(utility_metrics)

        # 负载相关指标
        load_metrics = self._evaluate_load_balance()
        metrics.update(load_metrics)

        # 公平性指标
        fairness_metrics = self._evaluate_fairness()
        metrics.update(fairness_metrics)

        return metrics

    def _evaluate_costs(self) -> Dict[str, float]:
        """评估成本指标"""
        if not self.allocations:
            return {
                'total_cost': 0,
                'avg_cost': 0,
                'total_payment': 0,
                'avg_payment': 0,
                'total_profit': 0,
                'avg_profit': 0
            }

        total_cost = sum(alloc.actual_cost for alloc in self.allocations.values())
        total_payment = sum(alloc.payment for alloc in self.allocations.values())
        total_profit = total_payment - total_cost

        return {
            'total_cost': total_cost,
            'avg_cost': total_cost / len(self.allocations),
            'total_payment': total_payment,
            'avg_payment': total_payment / len(self.allocations),
            'total_profit': total_profit,
            'avg_profit': total_profit / len(self.allocations)
        }

    def _evaluate_delays(self) -> Dict[str, float]:
        """评估延迟指标"""
        if not self.allocations:
            return {
                'total_delay': 0,
                'avg_delay': 0,
                'max_delay': 0,
                'deadline_violation_rate': 0
            }

        delays = []
        deadline_violations = 0

        for alloc in self.allocations.values():
            task = next(t for t in self.tasks if t.task_id == alloc.task_id)
            delays.append(alloc.completion_time)

            if alloc.completion_time > task.deadline:
                deadline_violations += 1

        return {
            'total_delay': sum(delays),
            'avg_delay': np.mean(delays),
            'max_delay': np.max(delays) if delays else 0,
            'deadline_violation_rate': deadline_violations / len(self.allocations)
        }

    def _evaluate_utilities(self) -> Dict[str, float]:
        """评估效用指标"""
        if not self.allocations:
            return {
                'total_user_utility': 0,
                'avg_user_utility': 0,
                'total_server_utility': 0,
                'avg_server_utility': 0,
                'social_welfare': 0
            }

        user_utilities = []
        server_utilities = []

        for alloc in self.allocations.values():
            task = next(t for t in self.tasks if t.task_id == alloc.task_id)
            user_utilities.append(alloc.utility(task))
            server_utilities.append(alloc.profit())

        total_user_utility = sum(user_utilities)
        total_server_utility = sum(server_utilities)

        return {
            'total_user_utility': total_user_utility,
            'avg_user_utility': np.mean(user_utilities),
            'total_server_utility': total_server_utility,
            'avg_server_utility': np.mean(server_utilities),
            'social_welfare': total_user_utility + total_server_utility
        }

    def _evaluate_load_balance(self) -> Dict[str, float]:
        """评估负载均衡"""
        if not self.allocations:
            return {
                'server_utilization': 0,
                'load_balance_index': 0,
                'load_variance': 0
            }

        # 统计每个服务器的负载
        server_loads = {server.server_id: 0 for server in self.servers}
        server_capacities = {server.server_id: server.cpu_capacity for server in self.servers}

        for alloc in self.allocations.values():
            task = next(t for t in self.tasks if t.task_id == alloc.task_id)
            server_loads[alloc.server_id] += task.computing_demand

        # 计算利用率
        utilizations = []
        for server_id, load in server_loads.items():
            capacity = server_capacities[server_id]
            if capacity > 0:
                utilizations.append(load / capacity)

        if not utilizations:
            return {
                'server_utilization': 0,
                'load_balance_index': 0,
                'load_variance': 0
            }

        # 计算负载均衡指数（Jain's Fairness Index）
        load_values = list(server_loads.values())
        if sum(load_values) == 0:
            fairness_index = 0
        else:
            fairness_index = (sum(load_values) ** 2) / (len(load_values) * sum(x ** 2 for x in load_values))

        # 计算负载方差
        load_variance = np.var(list(server_loads.values())) if len(server_loads) > 1 else 0

        return {
            'server_utilization': np.mean(utilizations),
            'load_balance_index': fairness_index,
            'load_variance': load_variance
        }

    def _evaluate_fairness(self) -> Dict[str, float]:
        """评估公平性指标"""
        if not self.allocations:
            return {
                'price_fairness': 0,
                'utility_fairness': 0,
                'gini_coefficient': 0
            }

        # 价格公平性（价格方差）
        prices = [alloc.payment for alloc in self.allocations.values()]
        price_fairness = 1 / (1 + np.var(prices)) if prices else 0

        # 效用公平性
        user_utilities = []
        for alloc in self.allocations.values():
            task = next(t for t in self.tasks if t.task_id == alloc.task_id)
            user_utilities.append(alloc.utility(task))

        utility_fairness = 1 / (1 + np.var(user_utilities)) if user_utilities else 0

        # 基尼系数
        gini_coefficient = self._calculate_gini_coefficient(prices) if prices else 0

        return {
            'price_fairness': price_fairness,
            'utility_fairness': utility_fairness,
            'gini_coefficient': gini_coefficient
        }

    def _calculate_gini_coefficient(self, values: List[float]) -> float:
        """计算基尼系数"""
        if not values:
            return 0

        # 排序
        sorted_values = np.sort(values)
        n = len(sorted_values)
        index = np.arange(1, n + 1)

        # 计算基尼系数
        gini = (np.sum((2 * index - n - 1) * sorted_values)) / (n * np.sum(sorted_values))
        return gini